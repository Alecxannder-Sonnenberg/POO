public class Despesa extends Transacoes {

	public Despesa(String cat, String data, double Valor, int par) {
		super(cat, data, Valor, par);
		// TODO Auto-generated constructor stub
	}
}
