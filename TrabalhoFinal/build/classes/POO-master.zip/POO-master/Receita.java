public class Receita extends Transacoes {

	public Receita(String cat, String data, double Valor, int par) {
		super(cat, data, Valor, par);
		// TODO Auto-generated constructor stub
	}

}
