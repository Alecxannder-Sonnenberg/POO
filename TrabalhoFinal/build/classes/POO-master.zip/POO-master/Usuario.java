public class Usuario {
	
	int idUsuario;
	String nome;
	String email;
	String telefone;
	String emprego;
	
	String dataSalario; //Procurar se tem uma variavel data (yy/mm/dd)
	
	double rendaFixa;
	
}
